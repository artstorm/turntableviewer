JS Turntable Viewer v1.1
========================
Flash Turntable Viewer by Johan Steen.


Description
===========
The JS Turntable Viewer is a flash based application, suitable to embed turntable renders of 3D models or sculpts on web pages. The Viewer can handle both a single turntable or a gallery of turntables in one instance.


Usage
=====
See: http://www.artstorm.net/plugins/turntable-flash-viewer/
for latest version and more usage instructions.


License
=======
This work is licensed under the Creative Commons Attribution-Noncommercial-Share Alike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.


Turntable Viewer Changelog
==========================

Version 1.1 - 18 Aug 2009
* First public release.
* Implemented a config class to be able to customize the colors for the turntable controller in an external XML file.

Version 1.0 - 13 Jan 2009
* Internal release for http://www.artstorm.net

